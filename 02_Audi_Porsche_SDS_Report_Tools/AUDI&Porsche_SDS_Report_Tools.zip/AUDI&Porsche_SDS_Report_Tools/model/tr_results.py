#! /usr/bin/env python
# -*- encoding:utf-8 -*-

import xlrd

ASR_DETAIL_KEYS = [u'测试集', u'Feature_ID', u'Asterix期望结果', u'录音文件', u'测试语料输入', u'测试语料输出',
            u'ASR归一化结果', u'ASR错误代码']
WORD_SUMMARY_KEYS = ['Asterix', '1-WER']
SENTENCE_SUMMARY_KEYS = ['Asterix', 'PASS Rate']
NLU_DETAIL_KEYS = [u'测试集', u'Feature_ID', u'Asterix期望结果', u'录音文件', u'测试语料输入', u'Asterix结果',
                   u'Asterix实际结果', u'NLU结果', u'Domain预期', u'Domain实际', u'Intent预期', u'Intent实际',
                   u'Slot预期', u'Slot实际', u'Comments']
NLU_SUMMARY_KEYS = ['Asterix', 'PASS Rate']

class GetTResult(object):
    def __init__(self, dir_file):
        self.wb = xlrd.open_workbook(dir_file)

    def sum_word_data(self):
        return self.sum_data(WORD_SUMMARY_KEYS, 0)

    def sum_sentence_data(self):
        return self.sum_data(SENTENCE_SUMMARY_KEYS, 1)

    def sum_nlu_data(self):
        return self.sum_data(NLU_SUMMARY_KEYS, 0)

    def detail_asr_data(self):
        return self.detail_data(ASR_DETAIL_KEYS)

    def detail_nlu_data(self):
        return self.detail_data(NLU_DETAIL_KEYS)

    def detail_data(self, KEYS):
        ws = self.wb.sheet_by_index(0)
        nrows = ws.nrows
        tags = [item.value for item in ws.row(0)]
        # 获取符合要求的列表
        cols = self.get_cols(tags, KEYS, 0)
        datas = []
        datas.append(KEYS)
        for row in range(1, nrows):
            data = [ws.cell_value(row, col) for col in cols]
            datas.append(data)
        return datas

    def sum_data(self, KEYS, start):
        wd = self.wb.sheet_by_index(1)
        nrows = wd.nrows
        tags = [item.value for item in wd.row(3)]
        cols = self.get_cols(tags, KEYS, start)
        sum_datas = []
        for row in range(4, nrows):
            data = [wd.cell_value(row, col) for col in cols]
            sum_datas.append(data)

        return sum_datas


    def get_cols(self, tags, keys, start):
        return [tags.index(key, start) for key in keys]




if __name__ == '__main__':
    dir_file = u'C:\\Users\\huizh\\Desktop\\Project\\AudiSOP4\\CLU37\\AUDI&Porsche_SDS_Report_Tools\\ASR\\20220406.105455_Mandarin_asr\\Result_20220406.105455_mandarin_online.xls'
    xr = GetTResult(dir_file)
    print (xr.sum_word_data())

