#! /usr/bin/env python
# -*- encoding:utf-8 -*-

import openpyxl
from model.Get_Config import Config
config = Config()

summary = {'word': 5, 'sentence': 8, 'nlu_stage': 12, 'nlu_live': 14}
index_testsuit = 1
index_category = 2
data_area_start = 19
if config.project.lower().strip() in ['audi', 'audiclu37']:
    data_area_end = 31
elif config.project.lower().strip() in ['porsche']:
    data_area_end = 23

class WriteResult(object):
    def __init__(self, dir_result_report):
        self.dir_result_report = dir_result_report
        self.wb = openpyxl.load_workbook(dir_result_report)
        self.wb.active
        self.sheets = self.wb.sheetnames
        self.sum_ws = self.wb[self.sheets[0]]



    def write_summary(self, testsuit, envoriment, sum_data):
        rowinfo = self.get_row_bycategory(self.get_row_bysuit(testsuit.lower()))
        for k, v in sum_data.items():
            for item in rowinfo:
                for data in v:
                    if item[0] == data[0]:
                        if envoriment != None:
                            self.sum_ws.cell(row=item[1], column=summary[k + '_' + envoriment]).value=data[1]
                        else:
                            self.sum_ws.cell(row=item[1], column=summary[k]).value=data[1]

    def write_data(self, langauge, enviroment, testtype, datas):
            sheet_name = self.get_sheetname(langauge, enviroment, testtype)
            print (sheet_name)
            ws = self.wb[sheet_name]
            # 是否已经有数据，有数据去掉第一行再写
            if ws.max_row > 1:
                datas = datas[1:]
            start_row = ws.max_row-1
            for i, data in enumerate(datas):
                for j, d in enumerate(data):
                    ws.cell(row=start_row+1+i, column=j+1).value = str(d)


    def get_row_bysuit(self, testsuit):
        testsuits = [self.sum_ws.cell(row=row, column=index_testsuit).value for row in range(data_area_start, data_area_end)]
        cols = {}
        start = data_area_start
        temp = []
        for item in testsuits:
            if item == None:
                cols[temp[-1]].append(start)
            else:
                cols.setdefault(item.lower(), []).append(start)
                temp.append(item.lower())
            start += 1
        print (cols)
        return cols[testsuit]

    def get_row_bycategory(self, rows):
        category_list = [(self.sum_ws.cell(row=row, column=index_category).value, row) for row in rows]
        print (category_list)
        return category_list

    def get_sheetname(self, language, environment, testtype):
        for sheet in self.sheets:
            if testtype == 'asr' and '%s_%s'%(language, testtype) == sheet:
                return sheet
            elif testtype == 'nlu' and '%s_%s_%s'%(language, testtype, environment) == sheet:
                return sheet

    def save(self, dir_report):
        self.wb.save(dir_report)

if __name__ == '__main__':
    FILE = r'C:\Users\huizh\Desktop\Project\AudiSOP4\CLU37\AUDI&Porsche_SDS_Report_Tools\Audi_CW15_SDS自动化测试报告.xlsx'
    wr = WriteResult(FILE)
    result = [['null', '98.43%'], ['nlu', '99.52%'], ['nlu_speech', '98.95%'], ['综合', '98.75%'], ['', '']]
    print (wr.get_sheetname('cantonese', None, 'asr'))

