import xlwt
from model.getconfig import ConfigParser

config = ConfigParser()

class XLSWriter(object):
    def __init__(self):
        self.work_book_file = xlwt.Workbook()
        self.asr_items = [u'场景', u'录音文件名',  u'测试语料输入', u'Category', u'ASR校正结果', u'语料识别输出']
        self.nlu_items = [u'测试集', u'录音文件名', u'测试语料输入', u'Category',  u'NLU校正结果', u'Domain预期', u'Domain实际', u'Intent预期', u'Intent实际', \
                     u'Slot预期', u'Slot实际', u'Comments']
        self.summary_items = [u'Scene', u'Category', u'下降率', u'Query总数', u'新增FAIL的数']
        self.style_head = xlwt.easyxf('font: bold on; align: vert centre, horiz center')
        self.style_data = xlwt.easyxf('align: vert centre, horiz center')
        self.head_list = [self.asr_items, self.nlu_items]


    def write_head(self, sheet_list):
        if config.compare_object.lower().strip() == 'nlu':
            for index, sheet in enumerate(sheet_list):
                sheet.write_merge(0, 0, 0, len(self.head_list[1]) - 1, u'生产环境', self.style_head)
                sheet.write_merge(0, 0, len(self.head_list[1]) + 4, len(self.head_list[1]) * 2 + 3, u'Stage环境',
                                  self.style_head)
                for i, d in enumerate(self.head_list[1]):
                    sheet.write(1, i, d, self.style_head)
                    sheet.write(1, i + len(self.head_list[1]) + 4, d, self.style_head)
        else:
            for index, sheet in enumerate(sheet_list):
                    sheet.write_merge(0, 0, 0, len(self.head_list[index])-1, u'生产环境',self.style_head)
                    sheet.write_merge(0, 0, len(self.head_list[index]) + 4, len(self.head_list[index]) * 2+3, u'Stage环境', self.style_head)
                    for i, d in enumerate(self.head_list[index]):
                        sheet.write(1, i, d, self.style_head)
                        sheet.write(1, i+len(self.head_list[index])+4, d, self.style_head)

    def write_data_asr(self, sheet, base_results_list, actual_results_list):
        for j, data in enumerate(base_results_list):
            for y, d in enumerate(data):
                sheet.write(j+2, y, d)

        for j, data  in enumerate(actual_results_list):
            for y, d in enumerate(data):
                sheet.write(j+2, y+len(self.asr_items) + 4, d)

    def write_data_nlu(self, sheet, base_results_list, actual_results_list):
        for j, data in enumerate(base_results_list):
            for y, d in enumerate(data):
                sheet.write(j+2, y, d)
        for j, data in enumerate(actual_results_list):
            for y, d in enumerate(data):
                sheet.write(j + 2, y + len(self.nlu_items) + 4, d)

    def write_analysis_head(self, sheet):
        # for index, sheet in enumerate(sheet_list):
        sheet.write_merge(0, 0, 0, len(self.summary_items)-1, "ASR 下降超过3%的Category", self.style_head)
        sheet.write_merge(0, 0, 7, 11, "NLU 下降超过3%的Category", self.style_head)
        for i, d in enumerate(self.summary_items):
            sheet.write(1, i, d, self.style_head)
            sheet.write(1, 7+i, d, self.style_head)

    def write_analysis_data(self, sheet, asr_bad_data, nlu_bad_data):
        asr_scene = [data[0] for data in asr_bad_data]
        row_start = 2
        for i, d in enumerate(sorted(list(set(asr_scene)))):
            sheet.write_merge(row_start, row_start+asr_scene.count(d)-1, 0, 0, d, self.style_head)
            row_start = row_start+asr_scene.count(d)
        for i, data in enumerate(asr_bad_data):
            for j, d in enumerate(data):
                if d not in asr_scene:
                    sheet.write(2+i, j, d, self.style_data)

        nlu_acene = [data[0] for data in nlu_bad_data]
        row_start = 2
        for i, d in enumerate(sorted(list(set(nlu_acene)))):
            sheet.write_merge(row_start, row_start+nlu_acene.count(d)-1, 7, 7, d, self.style_head)
            row_start = row_start+nlu_acene.count(d)
        for n, nlu_data in enumerate(nlu_bad_data):
            for m, d in enumerate(nlu_data):
                if d not in nlu_acene:
                    sheet.write(2+n, 7+m, d, self.style_data)

    def add_sheet(self, sheet_list):
        if isinstance(sheet_list, list):
            work_book_sheets = []
            for sheet in sheet_list:
                sheet = self.work_book_file.add_sheet(sheet)
                work_book_sheets.append(sheet)
            return work_book_sheets
        elif isinstance(sheet_list, str):
            sheet = self.work_book_file.add_sheet(sheet_list)
            return sheet

    def write_save(self, file_path):
        self.work_book_file.save(file_path)


