#! /usr/bin/env python
# -*- coding:utf-8 -*-

import xlrd
from model.getconfig import ConfigParser

config = ConfigParser()

class Analysis_Summary(object):
    def __init__(self, file):
        self.file = file
        self.data = xlrd.open_workbook(self.file)
        self.sheet = self.data.sheet_by_name("SUM_Result")
        self.Category_tag = 'Category'
        self.Eorror_tag = 'ERROR'
        self.FAIL_tag = 'FAIL'
        self.PASS_tag = 'PASS'
        self.Sum_tag = '总计'
        self.Word_tag = '1-WER'
        self.Sentence_tag = 'P/(P+F)'
        self.tags = [self.Category_tag, self.Eorror_tag, self.FAIL_tag, self.PASS_tag, self.Sum_tag, self.Word_tag, self.Sentence_tag]

    def asr_result_sum(self):
        # A - H 列
        self.nrow = self.sheet.nrows
        self.datas = {}
        tags = [self.sheet.cell_value(0, i) for i in range(0, self.sheet.ncols)]
        for x in range(1, self.nrow):
            result = {}
            for i, k in enumerate(tags):
                result[k] = self.table.cell_value(x, i)
            self.datas[result[self._audio_tag]] = result
        self.sheet.read()