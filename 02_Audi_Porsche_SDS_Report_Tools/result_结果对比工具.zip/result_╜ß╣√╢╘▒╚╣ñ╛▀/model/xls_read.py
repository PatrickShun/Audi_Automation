#! /usr/bin/env python
# -*- coding:utf-8 -*-

import xlrd
from model.getconfig import ConfigParser

config = ConfigParser()

class GetData(object):
    def __init__(self, file):
        self.file = file
        self.data = xlrd.open_workbook(self.file)
        self.table = self.data.sheet_by_index(0)
        self.nrow = self.table.nrows
        if config.compare_object.lower().strip() == 'nlu':
            self._suit_tag = u'测试集'
            self._category_tag = u'Category'
            self._input_tag = u'测试语料输入'
            self._nlu_result_tag = u'NLU校正结果'
            self._domain_expected_tag = u'Domain预期'
            self._domain_acutal_tag = u'Domain实际'
            self._intent_expected_tag = u'Intent预期'
            self._intent_acutal_tag = u'Intent实际'
            self._slot_expected_tag = u'Slot预期'
            self._slot_acutal_tag = u'Slot实际'
            self._comment_tag = u'Comments'
            self._tags = [self._suit_tag, self._category_tag, self._input_tag, self._nlu_result_tag, self._domain_expected_tag, self._domain_acutal_tag,\
                          self._intent_expected_tag, self._intent_acutal_tag, self._slot_expected_tag, self._slot_acutal_tag,\
                          self._comment_tag]
        else:
            self._audio_tag = u'录音文件名'
            self._input_tag = u'测试语料输入'
            self._category_tag = u'Category'
            self._asr_result_tag = u'ASR校正结果'
            self._output_tag = u'语料识别输出'
            self._nlu_result_tag = u'NLU校正结果'
            self._domain_expected_tag = u'Domain预期'
            self._domain_acutal_tag = u'Domain实际'
            self._intent_expected_tag = u'Intent预期'
            self._intent_acutal_tag = u'Intent实际'
            self._slot_expected_tag = u'Slot预期'
            self._slot_acutal_tag = u'Slot实际'
            self._comment_tag = u'Comments'
            self._tags = [self._audio_tag, self._input_tag, self._category_tag, self._asr_result_tag, self._output_tag, self._nlu_result_tag, self._domain_expected_tag,
                          self._domain_acutal_tag, self._intent_expected_tag, self._intent_acutal_tag, self._slot_expected_tag,
                          self._slot_acutal_tag, self._comment_tag]
        self.datas = {}
        tags = [self.table.cell_value(0, i) for i in range(0, self.table.ncols)]
        for x in range(1, self.nrow):
            result = {}
            for i, k in enumerate(tags):
                if config.compare_object.lower().strip() == 'nlu':
                    input_query = self.table.cell_value(x, tags.index(self._input_tag))
                    # if k == self._input_tag:
                    #     # if len(self.table.cell_value(x, i).split('/')) > 3:
                    #     #     result[k] ='/' + '/'.join(self.table.cell_value(x, i).split('/')[-2:])
                    #     # else:
                    #     # result[k] = self.table.cell_value(x, i)
                    #     input_query = self.table.cell_value(x, i)
                    # else:
                    result[k] = self.table.cell_value(x, i)

                    self.datas[input_query] = result
                    # print (self.datas)

                else:
                    if k == self._audio_tag:
                        if len(self.table.cell_value(x, i).split('/')) > 3:
                            result[k] ='/' + '/'.join(self.table.cell_value(x, i).split('/')[-2:])
                        else:
                            result[k] = self.table.cell_value(x, i)
                    else:
                        result[k] = self.table.cell_value(x, i)

                    self.datas[result[self._audio_tag]] = result

        #print (self.datas)

    def audios(self):
        return self.datas.keys()

    def input(self, audio):
        return self.datas[audio][self._input_tag]

    def output(self, audio):
        return self.datas[audio][self._output_tag]

    def suit(self, audio):
        return self.datas[audio][self._suit_tag]

    def category(self, audio):
        return self.datas[audio][self._category_tag]

    def asr_result(self, audio):
        return self.datas[audio][self._asr_result_tag]

    def nlu_result(self, audio):
        try:
            return self.datas[audio][self._nlu_result_tag]
        except:
            return self.datas[audio][u'TTS 结果']

    def domain_expected(self, audio):
        try:
            return self.datas[audio][self._domain_expected_tag]
        except:
            return ''

    def domain_acutal(self, audio):
        return self.datas[audio][self._domain_acutal_tag]

    def intent_expected(self, audio):
        try:
            return self.datas[audio][self._intent_expected_tag]
        except:
            return ''

    def intent_actual(self, audio):
        try:
            return self.datas[audio][self._intent_acutal_tag]
        except:
            return ''

    def slot_expected(self, audio):
        try:
            return self.datas[audio][self._slot_expected_tag]
        except:
            return '{}'

    def slot_acutal(self, audio):
        try:
            return self.datas[audio][self._slot_acutal_tag]
        except:
            return '{}'

    def comments(self, audio):
        return self.datas[audio][self._comment_tag]








