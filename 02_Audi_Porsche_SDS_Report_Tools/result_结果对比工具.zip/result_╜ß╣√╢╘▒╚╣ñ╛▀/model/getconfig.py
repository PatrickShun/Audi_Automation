#! /usr/bin/env python

import os
import configparser

# PWD = os.path.abspath(os.path.dirname(os.getcwd()))
PWD = r'C:\Users\huizh\Desktop\ASR模型更新\result_结果对比工具'
DIR_CONFIG = os.path.join(PWD, 'config.ini')


class ConfigParser(object):

    def __init__(self):
        self.conf = configparser.ConfigParser()
        self.conf.read(DIR_CONFIG, encoding='utf-8')
        self.project = os.path.join(PWD, self.conf.get('config', 'project'))
        self.src_path = os.path.join(PWD, self.conf.get('config', 'src_result'))
        self.dir_path = os.path.join(PWD, self.conf.get('config', 'dir_result'))

        self.compare_result = os.path.join(PWD, "%s_对比结果.xls"%self.project)
        self.compare_object = self.conf.get('config', 'compare_object')






