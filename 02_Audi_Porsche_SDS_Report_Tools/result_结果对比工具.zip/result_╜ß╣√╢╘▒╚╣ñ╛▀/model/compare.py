#! /usr/bin/env python
# -*- encoding:utf-8 -*-

import re
from model.getconfig import ConfigParser
from model.xls_read import GetData
from model.getsumdata import GetSumData


config = ConfigParser()

class Compare(object):
    def __init__(self, base_file, actual_file):
        self.nlu_result_key = u'NLU校正结果'
        self.asr_result_key = u'ASR校正结果'
        try:
            self.scene = re.findall(r'场景[0-9]', base_file)[0]
        except:
            self.scene = ''
        self.base_data = GetData(base_file)
        self.actual_data = GetData(actual_file)
        self.base_sum_data = GetSumData(base_file)
        self.actual_sum_data = GetSumData(actual_file)
        self.PASS_TAG = 'PASS'
        self.FAIL_TAG = 'FAIL'
        self.ERROR_TAG = 'ERROR'
        self.base_results_asr = []
        self.actual_results_asr = []
        self.base_results_nlu = []
        self.actual_results_nlu = []

    def compare_asr_sum(self):
        sentence_bad_categroy_data = []
        self.base_asr_sum_data = self.base_sum_data.asr_sum_data()
        self.actual_asr_sum_data = self.actual_sum_data.asr_sum_data()

        for line in self.actual_asr_sum_data:
            act_sentence_sum_result = line['P/(P+F)']
            act_category = line['Category']
            for i in self.base_asr_sum_data:
                if act_category == i['Category']:
                    base_sentence_sum_result = i['P/(P+F)']
                    if float(base_sentence_sum_result.replace('%',''))/100 - float(act_sentence_sum_result.replace('%', ''))/100 > 0.03:
                        gap_rate = '%.2f'%((float(act_sentence_sum_result.replace('%',''))/100 - float(base_sentence_sum_result.replace('%',''))/100)*100)
                        category_count = int(line['总计'])
                        gap_fail = int(line['FAIL'] - i['FAIL'])
                        sentence_bad_categroy_data.append([self.scene, act_category, gap_rate, category_count, gap_fail])
        return sentence_bad_categroy_data

    def compare_nlu_sum(self):
        nlu_bad_category_data = []
        self.base_nlu_sum_data = self.base_sum_data.nlu_sum_data()
        self.actual_nlu_sum_data = self.actual_sum_data.nlu_sum_data()

        for line in self.actual_nlu_sum_data:
            act_nlu_sum_result = line['P/(P+F)']
            act_category = line['Category']
            for i in self.base_nlu_sum_data:
                if act_category == i['Category']:
                    base_nlu_sum_result = i['P/(P+F)']
                    if float(base_nlu_sum_result.replace('%',''))/100 - float(act_nlu_sum_result.replace('%', ''))/100 > 0.03:
                        gap_rate = '%.2f'%((float(act_nlu_sum_result.replace('%',''))/100 - float(base_nlu_sum_result.replace('%',''))/100)*100)
                        category_count = int(line['总计'])
                        gap_fail = int(line['FAIL'] - i['FAIL'])
                        nlu_bad_category_data.append([self.scene, act_category, gap_rate, category_count, gap_fail])
        return nlu_bad_category_data

    def compare_nlu(self, category_list):
        for audio_name in self.base_data.audios():
            # print (audio_name)
            if category_list:
                if self.base_data.category(audio_name) in category_list:
                    print (audio_name, self.base_data.category(audio_name))
                    base_result = self.base_data.nlu_result(audio_name)
                    actual_result = self.actual_data.nlu_result(audio_name)
                    asr_actual = self.actual_data.asr_result(audio_name)
                    if actual_result == self.FAIL_TAG:
                        if asr_actual == self.PASS_TAG and base_result == self.PASS_TAG:
                            self.base_results_nlu.append([self.scene, audio_name, self.base_data.input(audio_name), self.base_data.category(audio_name), self.base_data.output(audio_name), self.base_data.nlu_result(audio_name),
                                                 self.base_data.domain_expected(audio_name), self.base_data.domain_acutal(audio_name),
                                                 self.base_data.intent_expected(audio_name),
                                                 self.base_data.intent_actual(audio_name), self.base_data.slot_expected(audio_name), self.base_data.slot_acutal(audio_name),
                                                 self.base_data.comments(audio_name)])

                            self.actual_results_nlu.append(
                                [self.scene, audio_name, self.actual_data.input(audio_name), self.actual_data.category(audio_name), self.actual_data.output(audio_name), self.actual_data.nlu_result(audio_name), self.actual_data.domain_expected(audio_name),
                                 self.actual_data.domain_acutal(audio_name), self.actual_data.intent_expected(audio_name), self.actual_data.intent_actual(audio_name),
                                 self.actual_data.slot_expected(audio_name), self.actual_data.slot_acutal(audio_name), self.actual_data.comments(audio_name)])

                            print('-'.join([base_result, actual_result]))
            else:
                base_result = self.base_data.nlu_result(audio_name)
                actual_result = self.actual_data.nlu_result(audio_name)
                if base_result == self.PASS_TAG and actual_result == self.FAIL_TAG:
                    self.base_results_nlu.append([self.base_data.suit(audio_name), audio_name, self.base_data.input(audio_name),
                                                  self.base_data.category(audio_name),
                                                  self.base_data.nlu_result(audio_name),
                                                  self.base_data.domain_expected(audio_name),
                                                  self.base_data.domain_acutal(audio_name),
                                                  self.base_data.intent_expected(audio_name),
                                                  self.base_data.intent_actual(audio_name),
                                                  self.base_data.slot_expected(audio_name),
                                                  self.base_data.slot_acutal(audio_name),
                                                  self.base_data.comments(audio_name)])

                    self.actual_results_nlu.append(
                        [self.actual_data.suit(audio_name), audio_name, self.actual_data.input(audio_name),
                         self.actual_data.category(audio_name),
                         self.actual_data.nlu_result(audio_name), self.actual_data.domain_expected(audio_name),
                         self.actual_data.domain_acutal(audio_name), self.actual_data.intent_expected(audio_name),
                         self.actual_data.intent_actual(audio_name),
                         self.actual_data.slot_expected(audio_name), self.actual_data.slot_acutal(audio_name),
                         self.actual_data.comments(audio_name)])

                    print('-'.join([base_result, actual_result]))

        return  self.base_results_nlu, self.actual_results_nlu

    def compare_asr(self, category_list):
        for audio_name in self.base_data.audios():
            # print(audio_name, self.base_data.category(audio_name))
            base_result = self.base_data.asr_result(audio_name)
            actual_result = self.actual_data.asr_result(audio_name)
            if base_result == self.PASS_TAG and actual_result == self.FAIL_TAG:
                if self.base_data.category(audio_name) in category_list:
                    print(base_result, actual_result)
                    print (self.base_data.category(audio_name), category_list)
                    self.base_results_asr.append([self.scene, audio_name, self.base_data.input(audio_name), self.base_data.category(audio_name), self.base_data.asr_result(audio_name), self.base_data.output(audio_name)])
                    self.actual_results_asr.append([self.scene, audio_name, self.actual_data.input(audio_name), self.actual_data.category(audio_name), self.actual_data.asr_result(audio_name), self.actual_data.output(audio_name)])

            #print('-'.join([audio_name, base_result, actual_result]))
        return  self.base_results_asr, self.actual_results_asr
