#! /usr/bin/env python
# -*- coding:utf-8 -*-
import os
import xlrd
from model.getconfig import ConfigParser

config = ConfigParser()

class GetSumData(object):
    def __init__(self, file):
        self.file = file
        self.data = xlrd.open_workbook(self.file)
        self.table = self.data.sheet_by_index(1)
        self.nrow = self.table.nrows
        self._category_tag = u'Category'
        self._Error_tag = u'ERROR'
        self._FAIL_tag = u'FAIL'
        self._PASS_tag = u'PASS'
        self._SUM_tag = u'总计'
        self._WORD_Result_tag = u'1-WER'
        self._SENTENCE_include_ERROR_tag = 'P/(P+F+E)'
        self._SENTENCE_Result_tag = u'P/(P+F)'
        self._MEANING_include_ERROR_tag = 'P/(P+F+E)'
        self._MEANING_Result_tag = u'P/(P+F)'
        self._ASR_tags = [self._category_tag, self._Error_tag, self._FAIL_tag, self._PASS_tag, self._SUM_tag, self._WORD_Result_tag, self._SENTENCE_include_ERROR_tag, self._SENTENCE_Result_tag]
        self._NLU_tags = [self._category_tag, self._Error_tag, self._FAIL_tag, self._PASS_tag, self._SUM_tag, self._MEANING_include_ERROR_tag, self._MEANING_Result_tag]

    def asr_sum_data(self):
        self.ASR_SUM_datas = []
        self.ASR_ncols = 7
        tags = [self.table.cell_value(1, i) for i in range(0, self.ASR_ncols+1)]
        for x in range(2, self.nrow):
            result = {}
            for i, k in enumerate(tags):
                result[k] = self.table.cell_value(x, i)
            self.ASR_SUM_datas.append(result)

        return self.ASR_SUM_datas


    def nlu_sum_data(self):
        self.NLU_SUM_datas = []
        self.NLU_ncols = 15

        tags = [self.table.cell_value(1, i) for i in range(9, self.NLU_ncols+1)]
        for x in range(2, self.nrow):
            result = {}
            for i , k in enumerate(tags):
                result[k] = self.table.cell_value(x, i+9)
            self.NLU_SUM_datas.append(result)
        return self.NLU_SUM_datas

if __name__ == '__main__':
    PWD = os.path.split(os.path.abspath(__file__))[0]
    dir_file = os.path.join(PWD, 'Result_粤语_场景1_mix.xls')
    datas = GetSumData(dir_file)
    asr_datas = datas.asr_sum_data()
    nlu_datas = datas.nlu_sum_data()
    print (asr_datas)
    print (nlu_datas)
