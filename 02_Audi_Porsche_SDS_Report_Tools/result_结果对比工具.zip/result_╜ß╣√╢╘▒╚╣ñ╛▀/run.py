#!/usr/bin/env python
# -*- encoding:utf-8 -*-

import os
from model.getconfig import ConfigParser
from model.xls_read import GetData
from model.xls_writer import XLSWriter
from model.compare import Compare

PWD = os.path.split(os.path.abspath(__file__))[0]

def files(dir_folder):
    file_list = {}
    for roots, dirs, files in os.walk(dir_folder):
        if dirs:
            for dir in dirs:
                for file in os.listdir(os.path.join(roots, dir)):
                    dir_file = os.path.join( os.path.join(roots, dir), file)
                    if dir_file.endswith('.xls') and 'Result' in file:
                        file_list.setdefault(file, dir_file)
        else:
            for file in files:
                dir_file = os.path.join(roots, file)
                if dir_file.endswith('.xls') and 'Result' in file:
                    file_list.setdefault(file, dir_file)

    print (file_list)
    return file_list



config = ConfigParser()


if config.compare_object.lower().strip() == 'nlu':
    base_files = files(config.src_path)
    dir_files = files(config.dir_path)
    base_results_list_nlu, actual_results_list_nlu = [], []
    for file_name, base_file in base_files.items():
        print (base_file)
        co = Compare(base_file, dir_files[file_name])
        base_result, actual_result = co.compare_nlu([])
        # print (base_result, actual_result)
        base_results_list_nlu += base_result
        actual_results_list_nlu += actual_result

    xls = XLSWriter()
    xls_sheet = xls.add_sheet(['NLU'])
    xls.write_head(xls_sheet)
    xls.write_data_nlu(xls_sheet[0], base_results_list_nlu, actual_results_list_nlu)
    xls.write_save(config.compare_result)

else:
    if os.path.isdir(config.src_path) and os.path.isdir(config.dir_path):
        sheet_list = ['ASR', 'NLU']
        analysis_sheet = 'summary'
        base_results_list_asr, actual_results_list_asr = [], []
        base_results_list_nlu, actual_results_list_nlu = [], []
        asr_bad_data = []
        nlu_bad_data = []
        b_file_list = sorted(os.listdir(config.src_path))
        a_file_list = sorted(os.listdir(config.dir_path))
        for i in range(len(b_file_list)):
            bad_category_asr, bad_category_nlu = [], []
            sheet_name = b_file_list[i].split('_')[-1]
            dir_b_file = os.path.join(os.path.join(PWD, config.src_path), b_file_list[i])
            dir_a_file = os.path.join(os.path.join(PWD, config.dir_path), a_file_list[i])
            co = Compare(dir_b_file, dir_a_file)
            # 分析下降超过3%的category
            asr_sum_bad = co.compare_asr_sum()
            print (asr_sum_bad)
            bad_category_asr = [item[1] for item in asr_sum_bad]
            asr_bad_data += asr_sum_bad
            nlu_sum_bad = co.compare_nlu_sum()
            bad_category_nlu = [item[1] for item in nlu_sum_bad]
            print (bad_category_nlu)
            nlu_bad_data += nlu_sum_bad

            # 对比nlu结果
            base_results_nlu, actual_results_nlu = co.compare_nlu(bad_category_nlu)
            base_results_list_nlu += base_results_nlu
            actual_results_list_nlu += actual_results_nlu
            # 对比ASR结果
            base_results_asr, actual_results_asr = co.compare_asr(bad_category_asr)
            print (base_results_asr, actual_results_asr)
            base_results_list_asr += base_results_asr
            actual_results_list_asr += actual_results_asr


        xls = XLSWriter()
        xls_sheet = xls.add_sheet(sheet_list)
        xls.write_head(xls_sheet)
        xls.write_data_asr(xls_sheet[0], base_results_list_asr, actual_results_list_asr)
        xls.write_data_nlu(xls_sheet[1], base_results_list_nlu, actual_results_list_nlu)
        xls_sheet = xls.add_sheet(analysis_sheet)
        xls.write_analysis_head(xls_sheet)
        xls.write_analysis_data(xls_sheet, asr_bad_data, nlu_bad_data)
        xls.write_save(config.compare_result)







# elif os.path.isfile(config.src_path) and os.path.isfile(config.dir_path):
#
#
#
# sd = GetData(config.src_path)
# dd = GetData(config.dir_path)
# base_results = []
# actual_results = []
# PASS_TAG = 'PASS'
# FAIL_TAG = 'FAIL'
#
# # for audio_name in sd.audios():
# #     if config.compare_object.lower().strip() == 'nlu':
# #         result_key = u'NLU校正结果'
# #         base_result = sd.nlu_result(audio_name)
# #         actual_result = dd.nlu_result(audio_name)
# #         if base_result == PASS_TAG and actual_result == FAIL_TAG:
# #             base_results.append([sd.input(audio_name), sd.output(audio_name), sd.nlu_result(audio_name),
# #                                  sd.domain_expected(audio_name), sd.domain_acutal(audio_name), sd.intent_expected(audio_name),
# #                                  sd.intent_actual(audio_name), sd.slot_expected(audio_name), sd.slot_acutal(audio_name), sd.comments(audio_name)])
# #
# #             actual_results.append([dd.input(audio_name), dd.output(audio_name), dd.nlu_result(audio_name), dd.domain_expected(audio_name),
# #                                    dd.domain_acutal(audio_name), dd.intent_expected(audio_name), dd.intent_actual(audio_name),
# #                                    dd.slot_expected(audio_name), dd.slot_acutal(audio_name), dd.comments(audio_name)])
# #
# #         print ('-'.join([base_result, actual_result]))
# #
# #     elif config.compare_object.lower().strip() == 'asr':
# #         result_key = u'ASR校正结果'
# #         base_result = sd.asr_result(audio_name)
# #         actual_result = dd.asr_result(audio_name)
# #
# #         if base_result == PASS_TAG and actual_result == FAIL_TAG:
# #             base_results.append([sd.input(audio_name), sd.asr_result(audio_name), sd.output(audio_name)])
# #             actual_results.append([dd.input(audio_name), dd.asr_result(audio_name), dd.output(audio_name)])
# #
# #         print ('-'.join([base_result, actual_result]))
#
# # print base_results
# # print actual_results
# XLSWriter(config.compare_result, base_results, actual_results)